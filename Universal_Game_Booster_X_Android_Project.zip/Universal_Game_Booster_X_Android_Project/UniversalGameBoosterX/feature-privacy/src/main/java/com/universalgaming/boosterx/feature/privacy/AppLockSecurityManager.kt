package com.universalgaming.boosterx.feature.privacy

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/**
 * Implements Section 28: Salted SHA-256 PIN verification backed by Android Keystore / EncryptedSharedPreferences.
 * Includes honest disclosure of PIN loss recovery behavior.
 */
object AppLockPinHasher {

    fun generateSaltBase64(): String {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        return Base64.getEncoder().encodeToString(salt)
    }

    fun hashPinWithSalt(pin: String, saltBase64: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(Base64.getDecoder().decode(saltBase64))
        val hashed = digest.digest(pin.toByteArray(Charsets.UTF_8))
        return Base64.getEncoder().encodeToString(hashed)
    }

    fun verifyPin(inputPin: String, saltBase64: String, expectedHashBase64: String): Boolean {
        if (inputPin.length < 4) return false
        val actual = hashPinWithSalt(inputPin, saltBase64)
        return MessageDigest.isEqual(
            actual.toByteArray(Charsets.UTF_8),
            expectedHashBase64.toByteArray(Charsets.UTF_8)
        )
    }

    fun getForgotPinExplanation(): String {
        return "For your security, Universal Game Booster X never uploads your PIN to any server and includes no hidden backdoor. If you forget your PIN and Biometric Unlock is not enabled, you must clear Application Data in Android Settings (which resets local notes and settings)."
    }
}
