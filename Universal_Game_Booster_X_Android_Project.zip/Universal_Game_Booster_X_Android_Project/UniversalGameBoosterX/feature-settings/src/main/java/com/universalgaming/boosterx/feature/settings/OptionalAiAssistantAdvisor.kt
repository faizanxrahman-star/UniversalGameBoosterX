package com.universalgaming.boosterx.feature.settings

/**
 * Implements Section 35: Optional Online AI Assistant with offline-first local rule engine.
 * Works 100% offline by default; requires explicit user consent before any diagnostic summary is shared.
 */
class OptionalAiAssistantAdvisor {

    fun explainMetricsOffline(
        batteryTempC: Float?,
        availableRamMb: Long,
        avgPingMs: Long?
    ): String {
        val parts = mutableListOf<String>()
        if (batteryTempC != null) {
            if (batteryTempC >= 41f) {
                parts.add("Thermal Analysis: Battery is at ${"%.1f".format(batteryTempC)}°C. Android's thermal daemon likely scales down prime CPU/GPU clocks to protect hardware.")
            } else {
                parts.add("Thermal Analysis: Battery is at a healthy ${"%.1f".format(batteryTempC)}°C — minimal thermal throttling expected.")
            }
        }
        parts.add("Memory Analysis: $availableRamMb MB RAM is currently available for game textures and audio buffers.")
        if (avgPingMs != null) {
            parts.add("Network Analysis: Measured RTT is $avgPingMs ms. For competitive shooters, <60 ms on 5GHz Wi-Fi is ideal.")
        }
        return parts.joinToString("

")
    }
}
