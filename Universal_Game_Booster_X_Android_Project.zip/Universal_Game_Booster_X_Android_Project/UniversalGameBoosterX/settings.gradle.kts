pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "UniversalGameBoosterX"

include(":app")
include(":core-common")
include(":core-ui")
include(":core-data")
include(":core-permissions")
include(":core-compatibility")
include(":feature-home")
include(":feature-games")
include(":feature-game-profiles")
include(":feature-performance")
include(":feature-network")
include(":feature-floating-panel")
include(":feature-popup-hub")
include(":feature-device-health")
include(":feature-battery")
include(":feature-storage")
include(":feature-tools")
include(":feature-qr")
include(":feature-notes")
include(":feature-file-transfer")
include(":feature-privacy")
include(":feature-backup")
include(":feature-settings")
