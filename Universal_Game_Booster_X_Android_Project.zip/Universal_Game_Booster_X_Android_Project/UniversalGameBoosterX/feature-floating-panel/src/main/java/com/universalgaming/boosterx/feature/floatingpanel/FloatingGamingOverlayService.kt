package com.universalgaming.boosterx.feature.floatingpanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.lifecycle.LifecycleService

/**
 * Implements Section 10 & 11.1 (System A):
 * Optional floating gaming panel for the booster app's own tools (Timer, Battery, Notes, Calculator, Emergency Close).
 * Respects SYSTEM_ALERT_WINDOW permission and stops immediately when closed.
 */
class FloatingGamingOverlayService : LifecycleService() {

    private var windowManager: WindowManager? = null
    private var rootOverlayView: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        startForegroundWithNotification()
        attachFloatingBubble()
    }

    private fun startForegroundWithNotification() {
        val channelId = "booster_overlay_channel"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Floating Gaming Panel",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("Universal Game Booster X Panel Active")
                .setContentText("Tap inside overlay to use mini-tools or close anytime.")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Universal Game Booster X Panel Active")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        }
        startForeground(1001, notification)
    }

    private fun attachFloatingBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(24, 16, 24, 16)
            setBackgroundColor(0xE60E1628.toInt())
        }

        val statusLabel = TextView(this).apply {
            text = "UGBX HUD • [Lag Mark] • [Close ✕]"
            setTextColor(0xFF00E5FF.toInt())
            textSize = 12f
            setOnClickListener {
                // Emergency close on tap
                stopSelf()
            }
        }

        container.addView(statusLabel)
        rootOverlayView = container
        windowManager?.addView(container, params)
    }

    override fun onDestroy() {
        rootOverlayView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (_: Exception) {
            }
        }
        rootOverlayView = null
        super.onDestroy()
    }
}
