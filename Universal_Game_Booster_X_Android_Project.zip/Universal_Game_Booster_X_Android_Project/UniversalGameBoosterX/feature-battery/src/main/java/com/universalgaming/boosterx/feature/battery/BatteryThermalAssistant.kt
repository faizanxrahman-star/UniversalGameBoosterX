package com.universalgaming.boosterx.feature.battery

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.provider.Settings

data class BatteryTelemetrySnapshot(
    val levelPct: Int?,
    val isCharging: Boolean,
    val chargingSource: String,
    val temperatureCelsius: Float?,
    val voltageMillivolts: Int?,
    val healthLabel: String,
    val coolingRecommendation: String
)

class BatteryThermalAssistant(private val context: Context) {

    fun readBatteryTelemetry(): BatteryTelemetrySnapshot {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return BatteryTelemetrySnapshot(
                levelPct = null,
                isCharging = false,
                chargingSource = "Unavailable",
                temperatureCelsius = null,
                voltageMillivolts = null,
                healthLabel = "Unavailable",
                coolingRecommendation = "Battery sticky broadcast unavailable."
            )

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) (level * 100) / scale else null

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)
        val source = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Charger"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB Port"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Pad"
            else -> "On Battery"
        }

        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        val tempC = if (tempTenths > 0) tempTenths / 10f else null
        val voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1).takeIf { it > 0 }

        val healthInt = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val healthLabel = when (healthInt) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good (Reported by BMS)"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheated"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Degraded / Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            else -> "Standard / Unknown"
        }

        val advice = when {
            tempC == null -> "Battery temperature sensor not exposed."
            tempC >= 43f -> "High temperature (${"%.1f".format(tempC)}°C). Pause gaming, unplug charger, remove thick case, and let the phone cool naturally at room temperature. Never place a phone in a freezer."
            tempC >= 39f -> "Warm (${"%.1f".format(tempC)}°C). Consider lowering in-game frame rate or screen brightness."
            else -> "Normal operating temperature (${"%.1f".format(tempC)}°C). Note: Battery temperature differs from internal CPU/GPU die temperature."
        }

        return BatteryTelemetrySnapshot(
            levelPct = pct,
            isCharging = isCharging,
            chargingSource = source,
            temperatureCelsius = tempC,
            voltageMillivolts = voltage,
            healthLabel = healthLabel,
            coolingRecommendation = advice
        )
    }

    fun buildSystemBatterySettingsIntent(): Intent {
        return Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
