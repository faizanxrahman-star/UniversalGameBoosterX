package com.universalgaming.boosterx.feature.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.universalgaming.boosterx.core.common.DashboardPreset
import com.universalgaming.boosterx.core.ui.HonestMetricCard

data class HomeDashboardSnapshot(
    val activePreset: DashboardPreset,
    val batteryPct: Int?,
    val batteryTempC: Float?,
    val thermalStatusLabel: String?,
    val availableRamMb: Long,
    val totalRamMb: Long,
    val freeStorageGb: String,
    val networkStatusLabel: String,
    val displayRefreshHz: Int,
    val favoriteGameCount: Int,
    val overlayGranted: Boolean,
    val visibleCardIds: List<String>
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeDashboardScreen(
    snapshot: HomeDashboardSnapshot,
    onPresetSelected: (DashboardPreset) -> Unit,
    onPrepareGameClick: () -> Unit,
    onToggleOverlayPanel: () -> Unit,
    onResetLayoutClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Universal Game Booster X",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Honest Diagnostics • Floating Workspace • Offline Utilities",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashboardPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = snapshot.activePreset == preset,
                        onClick = { onPresetSelected(preset) },
                        label = { Text(preset.label) }
                    )
                }
            }
        }

        if ("prepare" in snapshot.visibleCardIds) {
            item {
                HonestMetricCard(
                    title = "One-Tap Game Preparation",
                    valueText = "${snapshot.favoriteGameCount} Favorite Games Ready",
                    sourceLabel = "Pre-Flight Check",
                    unavailableReason = null,
                    onActionClick = onPrepareGameClick,
                    actionLabel = "Prepare Game Session"
                )
            }
        }

        if ("battery" in snapshot.visibleCardIds) {
            item {
                HonestMetricCard(
                    title = "Battery & Thermal Sensor",
                    valueText = snapshot.batteryPct?.let { pct ->
                        val tempStr = snapshot.batteryTempC?.let { " • ${"%.1f".format(it)}°C" } ?: ""
                        "$pct%$tempStr"
                    },
                    sourceLabel = "BatteryManager API",
                    unavailableReason = "Battery sensor broadcast not yet received."
                )
            }
        }

        if ("thermal" in snapshot.visibleCardIds) {
            item {
                HonestMetricCard(
                    title = "System Thermal Status & RAM",
                    valueText = "${snapshot.availableRamMb} MB Free / ${snapshot.totalRamMb} MB (${snapshot.thermalStatusLabel ?: "Normal"})",
                    sourceLabel = "ActivityManager + PowerManager",
                    unavailableReason = null
                )
            }
        }

        if ("storage" in snapshot.visibleCardIds) {
            item {
                HonestMetricCard(
                    title = "Available Internal Storage & Display",
                    valueText = "${snapshot.freeStorageGb} Free • ${snapshot.displayRefreshHz} Hz Display",
                    sourceLabel = "StatFs + Display API",
                    unavailableReason = null
                )
            }
        }

        if ("network" in snapshot.visibleCardIds) {
            item {
                HonestMetricCard(
                    title = "Current Network State",
                    valueText = snapshot.networkStatusLabel,
                    sourceLabel = "ConnectivityManager",
                    unavailableReason = null
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onToggleOverlayPanel,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (snapshot.overlayGranted) "Launch Floating Panel" else "Enable Overlay Panel")
                }
                OutlinedButton(
                    onClick = onResetLayoutClick,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Restore Default Layout")
                }
            }
        }
    }
}
