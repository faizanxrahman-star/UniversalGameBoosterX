package com.universalgaming.boosterx.feature.gameprofiles

import com.universalgaming.boosterx.core.data.GameProfileEntity

/**
 * Implements Section 7: Configurable game-preparation workflow and profiles.
 * Never pretends to force Android into undocumented kernel/CPU modes;
 * controls the booster's own polling frequency, warnings, and system settings shortcuts.
 */
object DefaultGameProfiles {
    val PERFORMANCE = GameProfileEntity(
        profileId = "performance",
        profileName = "Performance Monitoring",
        pollingIntervalMs = 2000L,
        showBatteryMetric = true,
        showThermalMetric = true,
        showNetworkMetric = true,
        offerDndShortcut = true,
        offerBrightnessShortcut = true,
        autoOpenFloatingPanel = true,
        reduceBoosterAnimations = true
    )

    val BALANCED = GameProfileEntity(
        profileId = "balanced",
        profileName = "Balanced (Default)",
        pollingIntervalMs = 5000L,
        showBatteryMetric = true,
        showThermalMetric = true,
        showNetworkMetric = true,
        offerDndShortcut = true,
        offerBrightnessShortcut = false,
        autoOpenFloatingPanel = true,
        reduceBoosterAnimations = false
    )

    val BATTERY_SAVER = GameProfileEntity(
        profileId = "battery_saver",
        profileName = "Battery Saver (Low Overhead)",
        pollingIntervalMs = 15000L,
        showBatteryMetric = true,
        showThermalMetric = false,
        showNetworkMetric = false,
        offerDndShortcut = false,
        offerBrightnessShortcut = true,
        autoOpenFloatingPanel = false,
        reduceBoosterAnimations = true
    )

    fun allDefaults(): List<GameProfileEntity> = listOf(PERFORMANCE, BALANCED, BATTERY_SAVER)
}

data class PreFlightChecklistResult(
    val selectedProfile: GameProfileEntity,
    val batteryPercentage: Int?,
    val batteryTempCelsius: Float?,
    val freeStorageBytes: Long,
    val isNetworkConnected: Boolean,
    val warnings: List<String>,
    val dndReady: Boolean
)

class GamePreparationEvaluator {
    fun evaluatePreFlight(
        profile: GameProfileEntity,
        batteryPct: Int?,
        batteryTempC: Float?,
        freeStorageBytes: Long,
        isNetworkConnected: Boolean,
        hasDndPermission: Boolean
    ): PreFlightChecklistResult {
        val warnings = mutableListOf<String>()
        if (batteryPct != null && batteryPct < 20) {
            warnings.add("Battery is below 20% ($batteryPct%). Consider connecting a charger gently or using Battery Saver profile.")
        }
        if (batteryTempC != null && batteryTempC >= 41.0f) {
            warnings.add("Battery temperature is elevated (${"%.1f".format(batteryTempC)}°C). Avoid heavy charging while gaming.")
        }
        if (freeStorageBytes < 1_500_000_000L) {
            warnings.add("Available storage is under 1.5 GB. Games may fail to download patches or cache shaders.")
        }
        if (!isNetworkConnected) {
            warnings.add("Device is currently offline. Online multiplayer games will not connect.")
        }
        return PreFlightChecklistResult(
            selectedProfile = profile,
            batteryPercentage = batteryPct,
            batteryTempCelsius = batteryTempC,
            freeStorageBytes = freeStorageBytes,
            isNetworkConnected = isNetworkConnected,
            warnings = warnings,
            dndReady = hasDndPermission
        )
    }
}
