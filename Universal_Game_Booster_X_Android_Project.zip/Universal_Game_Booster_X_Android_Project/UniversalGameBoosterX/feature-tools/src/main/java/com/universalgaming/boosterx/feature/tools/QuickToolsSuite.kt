package com.universalgaming.boosterx.feature.tools

import android.content.Context
import android.hardware.camera2.CameraManager
import android.view.InputDevice
import com.universalgaming.boosterx.core.common.AppResult
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Implements Section 12.1: Safe, exact BigDecimal calculator with division-by-zero protection.
 */
class BoosterCalculatorEngine {
    fun evaluateBinary(
        leftRaw: String,
        operator: Char,
        rightRaw: String
    ): AppResult<String> {
        val left = leftRaw.trim().toBigDecimalOrNull()
            ?: return AppResult.Error("Invalid number '$leftRaw'", "Input is not a valid decimal.", "Enter a valid number.")
        val right = rightRaw.trim().toBigDecimalOrNull()
            ?: return AppResult.Error("Invalid number '$rightRaw'", "Input is not a valid decimal.", "Enter a valid number.")

        return try {
            val result = when (operator) {
                '+' -> left.add(right)
                '-' -> left.subtract(right)
                '*', '×' -> left.multiply(right)
                '/', '÷' -> {
                    if (right.compareTo(BigDecimal.ZERO) == 0) {
                        return AppResult.Error(
                            whatFailed = "Division by zero",
                            whyFailed = "Cannot divide $leftRaw by 0.",
                            nextAction = "Change the divisor to a non-zero number."
                        )
                    }
                    left.divide(right, 8, RoundingMode.HALF_UP).stripTrailingZeros()
                }
                '%' -> left.multiply(right).divide(BigDecimal(100), 8, RoundingMode.HALF_UP).stripTrailingZeros()
                else -> return AppResult.Error("Unsupported operator '$operator'", "Unknown symbol.", "Use +, -, ×, ÷, or %.")
            }
            AppResult.Success(result.toPlainString())
        } catch (e: Exception) {
            AppResult.Error("Calculation error", e.localizedMessage ?: "Arithmetic overflow", "Clear and try again.")
        }
    }
}

/**
 * Implements Section 21: Controller and Input Lab using Android InputDevice APIs.
 */
data class ConnectedControllerInfo(
    val deviceId: Int,
    val name: String,
    val vendorId: Int,
    val productId: Int,
    val hasJoystickAxes: Boolean,
    val hasGamepadButtons: Boolean
)

class ControllerAndSensorLab(private val context: Context) {
    fun detectGameControllers(): List<ConnectedControllerInfo> {
        val ids = InputDevice.getDeviceIds()
        val list = mutableListOf<ConnectedControllerInfo>()
        for (id in ids) {
            val dev = InputDevice.getDevice(id) ?: continue
            val sources = dev.sources
            val isGamepad = (sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
            val isJoystick = (sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
            if (isGamepad || isJoystick) {
                list.add(
                    ConnectedControllerInfo(
                        deviceId = id,
                        name = dev.name ?: "Controller #$id",
                        vendorId = dev.vendorId,
                        productId = dev.productId,
                        hasJoystickAxes = isJoystick,
                        hasGamepadButtons = isGamepad
                    )
                )
            }
        }
        return list
    }

    fun toggleFlashlightSafely(enable: Boolean): AppResult<Boolean> {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                ?: return AppResult.Error("Flashlight unavailable", "CameraManager service missing.", "Use hardware torch.")
            val cameraId = cm.cameraIdList.firstOrNull()
                ?: return AppResult.Error("No camera flash found", "Device reports no camera units.", "Flashlight unsupported.")
            cm.setTorchMode(cameraId, enable)
            AppResult.Success(enable)
        } catch (e: Exception) {
            AppResult.Error(
                whatFailed = "Could not toggle flashlight",
                whyFailed = e.localizedMessage ?: "Camera in use or torch unsupported.",
                nextAction = "Close camera apps or use Quick Settings torch tile."
            )
        }
    }
}
