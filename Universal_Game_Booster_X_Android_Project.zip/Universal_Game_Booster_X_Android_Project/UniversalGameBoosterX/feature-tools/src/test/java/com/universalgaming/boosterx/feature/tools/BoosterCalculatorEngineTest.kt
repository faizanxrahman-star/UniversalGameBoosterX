package com.universalgaming.boosterx.feature.tools

import com.universalgaming.boosterx.core.common.AppResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BoosterCalculatorEngineTest {
    private val engine = BoosterCalculatorEngine()

    @Test
    fun `addition and decimal precision work accurately`() {
        val res = engine.evaluateBinary("12.5", '+', "7.25")
        assertTrue(res is AppResult.Success)
        assertEquals("19.75", (res as AppResult.Success).data)
    }

    @Test
    fun `division by zero returns structured AppResult Error`() {
        val res = engine.evaluateBinary("42", '÷', "0")
        assertTrue(res is AppResult.Error)
        assertEquals("Division by zero", (res as AppResult.Error).whatFailed)
    }
}
