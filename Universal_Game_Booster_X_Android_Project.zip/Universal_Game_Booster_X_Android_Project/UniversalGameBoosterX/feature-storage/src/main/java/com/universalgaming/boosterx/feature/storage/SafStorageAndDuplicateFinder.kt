package com.universalgaming.boosterx.feature.storage

import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.InputStream
import java.security.MessageDigest

data class StorageOverview(
    val freeBytes: Long,
    val totalBytes: Long,
    val appSpecificBytes: Long,
    val scopeExplanation: String
)

data class ScannedFileMetadata(
    val uriString: String,
    val displayName: String,
    val sizeBytes: Long,
    val sha256Hash: String? = null
)

data class DuplicateCandidateGroup(
    val groupKey: String,
    val confidenceDescription: String,
    val files: List<ScannedFileMetadata>
)

/**
 * Implements Section 15: Storage dashboard and user-selected duplicate finder.
 * Never automatically deletes files or claims 'deep cleaning' of restricted system directories.
 */
class SafStorageAndDuplicateFinder(private val context: Context) {

    fun getStorageOverview(): StorageOverview {
        val stat = StatFs(Environment.getDataDirectory().path)
        val free = stat.availableBytes
        val total = stat.totalBytes
        val appDirSize = context.filesDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

        return StorageOverview(
            freeBytes = free,
            totalBytes = total,
            appSpecificBytes = appDirSize,
            scopeExplanation = "Android Scoped Storage protects private folders of other apps. Universal Game Booster X scans only folders you explicitly grant via Storage Access Framework."
        )
    }

    fun findDuplicatesInList(
        files: List<ScannedFileMetadata>,
        requireContentHash: Boolean = true
    ): List<DuplicateCandidateGroup> {
        // Group first by exact byte size (> 0)
        val bySize = files.filter { it.sizeBytes > 0L }.groupBy { it.sizeBytes }
        val results = mutableListOf<DuplicateCandidateGroup>()

        for ((size, candidates) in bySize) {
            if (candidates.size < 2) continue
            if (requireContentHash && candidates.all { !it.sha256Hash.isNullOrBlank() }) {
                val byHash = candidates.groupBy { it.sha256Hash!! }
                for ((hash, exactMatches) in byHash) {
                    if (exactMatches.size >= 2) {
                        results.add(
                            DuplicateCandidateGroup(
                                groupKey = "SHA-256: ${hash.take(12)}… ($size bytes)",
                                confidenceDescription = "High Confidence (Exact Size + SHA-256 Content Match)",
                                files = exactMatches
                            )
                        )
                    }
                }
            } else {
                val byNameAndSize = candidates.groupBy { it.displayName.lowercase() }
                for ((name, matches) in byNameAndSize) {
                    if (matches.size >= 2) {
                        results.add(
                            DuplicateCandidateGroup(
                                groupKey = "$name ($size bytes)",
                                confidenceDescription = "Medium Confidence (Matching Filename + Exact Size)",
                                files = matches
                            )
                        )
                    }
                }
            }
        }
        return results
    }

    fun computeSha256(inputStream: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(8192)
        var read: Int
        while (inputStream.read(buffer).also { read = it } != -1) {
            digest.update(buffer, 0, read)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
