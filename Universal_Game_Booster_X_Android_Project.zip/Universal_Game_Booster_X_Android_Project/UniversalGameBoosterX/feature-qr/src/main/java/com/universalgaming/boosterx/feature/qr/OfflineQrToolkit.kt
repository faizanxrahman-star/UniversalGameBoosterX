package com.universalgaming.boosterx.feature.qr

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.universalgaming.boosterx.core.common.AppResult

/**
 * Implements Section 14: Offline QR generation and safe URL preview inspection.
 * Never automatically opens decoded URLs or sends scanned content to any server.
 */
class OfflineQrToolkit {

    fun generateQrBitmap(content: String, sizePx: Int = 512): AppResult<Bitmap> {
        val trimmed = content.trim()
        if (trimmed.isEmpty()) {
            return AppResult.Error(
                whatFailed = "QR code generation failed",
                whyFailed = "Input text or URL is empty.",
                nextAction = "Enter text, Wi-Fi info, or a link before generating."
            )
        }
        return try {
            val matrix = MultiFormatWriter().encode(trimmed, BarcodeFormat.QR_CODE, sizePx, sizePx)
            val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
            for (x in 0 until sizePx) {
                for (y in 0 until sizePx) {
                    bmp.setPixel(x, y, if (matrix.get(x, y)) Color.BLACK else Color.WHITE)
                }
            }
            AppResult.Success(bmp)
        } catch (e: Exception) {
            AppResult.Error(
                whatFailed = "QR encoding failed",
                whyFailed = e.localizedMessage ?: "Input too long for standard QR matrix.",
                nextAction = "Shorten the input text and retry."
            )
        }
    }

    fun inspectDecodedTextSafety(rawDecoded: String): Pair<String, String> {
        val lower = rawDecoded.trim().lowercase()
        return when {
            lower.startsWith("http://") -> "Unencrypted HTTP Link" to "Warning: This link uses unencrypted HTTP. Preview the domain carefully before opening in browser."
            lower.startsWith("https://") -> "HTTPS Web Link" to "Preview link destination below. We never open links automatically."
            lower.startsWith("wifi:") -> "Wi-Fi Network Credentials" to "Contains SSID/password configuration."
            lower.startsWith("begin:vcard") -> "Contact Card (vCard)" to "Review contact fields before saving."
            else -> "Plain Text / Code" to "Safe offline text."
        }
    }
}
