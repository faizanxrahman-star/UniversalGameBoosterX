package com.universalgaming.boosterx.core.common

/**
 * Standard result wrapper enforcing Section 40 (Error Handling):
 * Every failure must explain what failed, why it failed, what the user can do next,
 * whether data was changed, and whether retrying is safe.
 */
sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Error(
        val whatFailed: String,
        val whyFailed: String,
        val nextAction: String,
        val dataChanged: Boolean = false,
        val canRetrySafely: Boolean = true,
        val exception: Throwable? = null
    ) : AppResult<Nothing>
}

enum class ModuleCompletionState {
    PLANNED,
    IN_DEVELOPMENT,
    IMPLEMENTED,
    TESTED,
    VERIFIED_ON_REAL_DEVICE,
    LIMITED_OR_UNSUPPORTED
}

enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    HINDI("hi", "हिन्दी (Hindi)"),
    HINGLISH("en-IN", "Hinglish (Roman Hindi)")
}

enum class BoosterThemeMode(val id: String, val title: String) {
    NEON_BLUE("neon_blue", "Neon Blue + Black (Default)"),
    RGB_CYBER("rgb_cyber", "RGB Cyber"),
    AMOLED_BLACK("amoled_black", "AMOLED Black"),
    CLEAN_LIGHT("clean_light", "Clean Light"),
    CUSTOM_ACCENT("custom_accent", "Custom Accent")
}

enum class DashboardPreset(val id: String, val label: String) {
    GAMING("gaming", "Gaming Dashboard"),
    DAILY_TOOLS("daily_tools", "Daily Tools Hub"),
    DEVICE_HEALTH("device_health", "Device Health Center")
}
