package com.universalgaming.boosterx.feature.filetransfer

import java.io.File

data class TransferManifestHeader(
    val senderDeviceName: String,
    val fileName: String,
    val fileSizeBytes: Long,
    val sha256Checksum: String,
    val pairingPinCode: String
)

/**
 * Implements Section 16: Explicit device-to-device local transfer validation,
 * filename sanitization against path traversal (Section 41), and checksum verification.
 */
object LocalPeerTransferValidator {

    fun sanitizeIncomingFileName(rawName: String): String {
        // Prevent path traversal such as "../../evil.apk"
        val stripped = File(rawName).name
            .replace(Regex("[^a-zA-Z0-9._-]"), "_")
            .trim('_')
        return if (stripped.isBlank()) "received_file.bin" else stripped
    }

    fun verifyReceivedIntegrity(expectedSha256: String, actualSha256: String): Boolean {
        return expectedSha256.equals(actualSha256, ignoreCase = true)
    }
}
