package com.universalgaming.boosterx.feature.games

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.universalgaming.boosterx.core.common.AppResult
import com.universalgaming.boosterx.core.data.GameEntryEntity

/**
 * Implements Section 6: Installed game discovery using supported Android APIs,
 * respecting Android 11+ package visibility rules, and safe intent launching.
 */
class GameDiscoveryManager(private val context: Context) {

    fun discoverInstalledGames(): List<GameEntryEntity> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
        }

        return resolveInfos.mapNotNull { info ->
            val appInfo = info.activityInfo?.applicationInfo ?: return@mapNotNull null
            val pkg = appInfo.packageName
            if (pkg == context.packageName) return@mapNotNull null

            val isCategorizedAsGame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else {
                @Suppress("DEPRECATION")
                (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }

            if (!isCategorizedAsGame) return@mapNotNull null

            val label = appInfo.loadLabel(pm)?.toString() ?: pkg
            val version = try {
                pm.getPackageInfo(pkg, 0).versionName
            } catch (_: Exception) {
                null
            }

            GameEntryEntity(
                packageName = pkg,
                appName = label,
                versionName = version,
                category = "Installed Game",
                isFavorite = false,
                isManuallyAdded = false
            )
        }.distinctBy { it.packageName }
    }

    fun launchGameSafely(packageName: String): AppResult<Unit> {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
            ?: return AppResult.Error(
                whatFailed = "Could not launch $packageName",
                whyFailed = "The application is either uninstalled, disabled, or does not expose a LAUNCHER activity.",
                nextAction = "Verify that the game is installed in Android Settings or remove the entry from your Game Library.",
                dataChanged = false,
                canRetrySafely = true
            )

        return try {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            context.startActivity(launchIntent)
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(
                whatFailed = "Game launch failed for $packageName",
                whyFailed = e.localizedMessage ?: "Security or ActivityNotFound exception.",
                nextAction = "Try opening the game from your home screen launcher.",
                dataChanged = false,
                canRetrySafely = true,
                exception = e
            )
        }
    }
}
