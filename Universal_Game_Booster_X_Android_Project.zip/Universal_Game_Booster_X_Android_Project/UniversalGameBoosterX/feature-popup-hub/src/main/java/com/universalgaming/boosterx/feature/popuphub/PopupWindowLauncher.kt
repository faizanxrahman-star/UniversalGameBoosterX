package com.universalgaming.boosterx.feature.popuphub

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Build
import com.universalgaming.boosterx.core.common.AppResult
import com.universalgaming.boosterx.core.compatibility.SmartCompatibilityEngine

/**
 * Implements Section 11 (System B):
 * Launches third-party apps in native Freeform/Multi-Window popup mode ONLY where Android/OEM supports it.
 * Never claims SYSTEM_ALERT_WINDOW can embed arbitrary third-party apps.
 */
class PopupWindowLauncher(
    private val context: Context,
    private val compatibilityEngine: SmartCompatibilityEngine
) {
    fun launchInSupportedPopupOrExplain(
        packageName: String,
        bounds: Rect = Rect(80, 160, 920, 1480)
    ): AppResult<String> {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
            ?: return AppResult.Error(
                whatFailed = "Cannot open $packageName",
                whyFailed = "App is not installed or has no launchable main activity.",
                nextAction = "Select an installed application from the Popup Launcher list."
            )

        val supportsFreeform = compatibilityEngine.isFreeformWindowManagementSupported()
        val oem = compatibilityEngine.detectOemFamily()

        if (!supportsFreeform) {
            return AppResult.Error(
                whatFailed = "Native Freeform Popup mode is disabled on this device",
                whyFailed = "Android blocks regular apps from embedding third-party apps without system Freeform Window Management (${oem.displayName}).",
                nextAction = "${oem.multitaskingNotes} You can also launch the app in standard Split-Screen or enable 'Force activities to be resizable / Freeform windows' in Android Developer Options.",
                dataChanged = false,
                canRetrySafely = true
            )
        }

        return try {
            launchIntent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK
            )
            val options = ActivityOptions.makeBasic()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                options.launchBounds = bounds
            }
            context.startActivity(launchIntent, options.toBundle())
            AppResult.Success("Launched $packageName requesting native multi-window bounds.")
        } catch (e: Exception) {
            AppResult.Error(
                whatFailed = "System rejected freeform window launch for $packageName",
                whyFailed = e.localizedMessage ?: "Target app does not support resizeableActivity.",
                nextAction = "Open $packageName normally or use System A (Booster Floating Mini-Tools).",
                exception = e
            )
        }
    }
}
