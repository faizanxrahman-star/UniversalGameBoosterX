# Release Build & Signing Guide (Section 43)

## 1. Generating a Release Keystore
Run the following command on your development machine (never commit `.jks` files or passwords to Git):
```bash
keytool -genkey -v -keystore boosterx-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias boosterx
```

## 2. Configuring `local.properties` / Environment Variables
Provide signing credentials via environment variables or untracked `keystore.properties`:
```properties
BOOSTERX_STORE_FILE=/secure/path/boosterx-release-key.jks
BOOSTERX_STORE_PASSWORD=your_store_password
BOOSTERX_KEY_ALIAS=boosterx
BOOSTERX_KEY_PASSWORD=your_key_password
```

## 3. Building & Verifying the Release APK / AAB
```bash
./gradlew testDebugUnitTest
./gradlew assembleRelease
./gradlew bundleRelease
```
Verify the signed artifact using `apksigner`:
```bash
apksigner verify --verbose app/build/outputs/apk/release/app-release.apk
```
