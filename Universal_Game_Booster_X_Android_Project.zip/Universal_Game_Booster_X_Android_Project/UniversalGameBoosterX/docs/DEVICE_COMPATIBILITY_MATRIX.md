# Device & OEM Capability Matrix (Section 3.2 & Section 33)

Universal Game Booster X uses runtime capability detection (`SmartCompatibilityEngine`) rather than hard-coded brand assumptions.

| OEM / Family | System A: Booster Floating Overlay (`SYSTEM_ALERT_WINDOW`) | System B: Third-Party App Popup Windows | Thermal Status API (`PowerManager`) | Notes & Settings Guidance |
| :--- | :--- | :--- | :--- | :--- |
| **Samsung (One UI)** | Supported (Requires user grant in Special Access) | Supported via One UI Multi Window / Pop-up View & Samsung DeX | Supported on Android 10+ (API 29+) | Enable *Settings > Advanced features > Multi window* for best freeform behavior. |
| **Xiaomi / Redmi / POCO (MIUI / HyperOS)** | Supported (Requires 'Display pop-up windows while running in background') | Supported via native MIUI/HyperOS Floating Windows sidebar | Supported on Android 10+; falls back to Battery °C | Grant 'Autostart' and 'Display pop-up window' in MIUI Security App if overlay closes. |
| **OPPO (ColorOS)** | Supported | Supported via ColorOS Flexible Windows / Smart Sidebar | Supported on Android 10+ | Disable aggressive battery freeze if session timer stops in background. |
| **Realme (Realme UI)** | Supported | Supported via Realme UI Mini Window / Flexible Window | Supported on Android 10+ | Uses standard Android overlay permission flow. |
| **Vivo / iQOO (FuntouchOS / OriginOS)** | Supported | Supported via Small Window mode in system multitasking | Supported on Android 10+ | Ultra Game Mode is controlled by Vivo system settings; Booster X complements it with notes/timers. |
| **OnePlus (OxygenOS)** | Supported | Supported via OxygenOS Floating Window & Split View | Supported on Android 10+ | Full 120Hz display refresh rate readout supported. |
| **Motorola (MyUX / Hello UI)** | Supported | Supported via Android Freeform & Ready For / Smart Connect | Supported on Android 10+ | Near-stock Android behavior. |
| **Google Pixel (Pixel UI)** | Supported | Supported via Split Screen; Freeform requires Developer Options toggle | Full `getCurrentThermalStatus()` & `getThermalHeadroom()` support | Enable *Freeform windows* in Developer Options to launch third-party apps in floating bounds. |
| **Nokia / HMD & Stock Android** | Supported (Unavailable on some Android Go editions) | Standard Android Split-Screen | Supported on Android 10+ | Android Go devices that disable `SYSTEM_ALERT_WINDOW` automatically fall back to in-app tools. |
