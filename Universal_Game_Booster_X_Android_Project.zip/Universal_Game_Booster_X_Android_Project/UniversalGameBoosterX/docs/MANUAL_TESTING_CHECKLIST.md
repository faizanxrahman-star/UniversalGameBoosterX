# Manual QA & Accessibility Testing Checklist (Section 42)

- [ ] **First Launch & Onboarding:** Verify app opens into `Neon Blue + Black` default theme offline with zero required permissions at startup.
- [ ] **Theme & Language Persistence:** Switch between all 5 themes (`Neon Blue`, `RGB Cyber`, `AMOLED Black`, `Clean Light`, `Custom`) and 3 languages (`English`, `Hindi`, `Hinglish`), restart app, and confirm state persists via DataStore.
- [ ] **Game Discovery & Safe Launch:** Verify installed games with `CATEGORY_GAME` appear, manual package addition works, removing a game from the library does **not** uninstall the app, and uninstalled packages show a clear `AppResult.Error` message.
- [ ] **One-Tap Game Preparation:** Run pre-flight check under `Performance`, `Balanced`, and `Battery Saver` profiles; verify warnings trigger when battery < 20%, temp >= 41°C, or offline.
- [ ] **System A Floating Gaming Panel:** Request `SYSTEM_ALERT_WINDOW` at point of activation, verify floating HUD appears, drag/reposition works, and tapping `[Close ✕]` stops `FloatingGamingOverlayService` immediately.
- [ ] **System B Popup Hub:** Attempt launching an app in Freeform mode; verify honest fallback guidance appears when `FEATURE_FREEFORM_WINDOW_MANAGEMENT` is false.
- [ ] **Network Lab:** Test latency/DNS check while online and in Airplane Mode; verify offline state reports `Offline` gracefully without crashing.
- [ ] **Storage & Duplicate Finder:** Select a folder via SAF, test SHA-256 duplicate grouping, and confirm no file is ever deleted without explicit user confirmation.
- [ ] **Backup & Restore:** Export a `.json` backup, test importing with an existing profile ID, and verify conflict detection previews before overwriting.
- [ ] **Accessibility Audit:** Test with TalkBack enabled and Android display font scale at `200%`; confirm no controls are clipped when the software keyboard is open.
