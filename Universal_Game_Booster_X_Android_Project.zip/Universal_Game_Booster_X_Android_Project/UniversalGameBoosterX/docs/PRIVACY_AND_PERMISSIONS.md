# Privacy & Permission Documentation (Section 27 & Section 41)

## Zero-Telemetry Offline-First Guarantee
Universal Game Booster X requires **no account**, **no cloud login**, and contains **zero third-party analytics or ad SDKs**. All notes, clipboard snippets, session journals, and game profiles are stored locally in Room (`universal_game_booster_x.db`) and Jetpack DataStore.

## Point-of-Need Permission Matrix

| Permission | Feature Requiring It | When Requested | Fallback When Denied |
| :--- | :--- | :--- | :--- |
| `INTERNET` & `ACCESS_NETWORK_STATE` | Network Lab (Ping/Jitter/DNS test) | At runtime when running a network test | All offline tools, game profiles, notes, and hardware monitors work 100% offline. |
| `SYSTEM_ALERT_WINDOW` | System A Floating Gaming Panel | Only when user taps *Enable Overlay Panel* | All mini-tools (Calculator, Timer, Notes, Lag Marker) work inside the main app. |
| `ACCESS_NOTIFICATION_POLICY` | Do Not Disturb toggle in Game Prep & Focus Timer | Only when user enables DND automation | Provides direct intent shortcut to system Sound/DND settings. |
| `CAMERA` | QR / Barcode Scanner | Only when user opens Camera Scanner tab | Offline QR Code Generator and text/URL inspector work without Camera permission. |
| `POST_NOTIFICATIONS` | Foreground Overlay Service & Timer alerts (Android 13+) | When starting a background timer or overlay | In-app visual timers and manual stop controls remain active. |
| `PACKAGE_USAGE_STATS` | Optional automatic playtime attribution | Only if user enables Usage Access in Privacy Center | Manual session timer logs playtime accurately without Usage Access. |
