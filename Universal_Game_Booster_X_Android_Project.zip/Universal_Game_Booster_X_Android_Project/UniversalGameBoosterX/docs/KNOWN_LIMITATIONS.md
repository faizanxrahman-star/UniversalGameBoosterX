# Non-Negotiable Technical Limitations & Honesty Disclosures (Section 46)

Universal Game Booster X strictly adheres to Android's security sandbox and never makes exaggerated claims:

1. **No Fake FPS Counter for Third-Party Games:** Normal Android apps cannot access another game's private `SurfaceFlinger` rendering pipeline without root or ADB `dumpsys` privileges. We display the real hardware **Display Refresh Rate (Hz)** and provide **Lag Replay Markers** so players can log exact timestamps alongside real battery temperature and RAM state.
2. **No Fake Ping Lowering or Server Routing:** The Network Lab measures real TCP handshake RTT latency, jitter, packet loss, and DNS lookup time to transparent endpoints (such as `1.1.1.1:53`). It cannot alter a game publisher's matchmaking server or bypass ISP routing.
3. **No Fake RAM Killer / Force-Stop All:** Killing background processes arbitrarily on modern Android causes higher battery drain when services restart. Our **Background App Advisor** educates the user and links directly to Android's native Battery Optimization settings.
4. **System A vs. System B Floating Windows:** `SYSTEM_ALERT_WINDOW` allows rendering Universal Game Booster X's own mini-tools (System A) over games. Embedding arbitrary third-party apps inside custom views is blocked by Android security; therefore, System B uses native `ActivityOptions.setLaunchBounds` freeform windowing where supported by the OS/OEM, and explains split-screen alternatives when unsupported.
5. **Scoped Storage & Privacy:** File management and duplicate detection operate strictly on folders explicitly authorized by the user via Android's Storage Access Framework (`ACTION_OPEN_DOCUMENT_TREE`). Background clipboard scraping is never performed.
