package com.universalgaming.boosterx.core.permissions

import android.Manifest
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.core.content.ContextCompat

enum class BoosterPermissionType(
    val id: String,
    val title: String,
    val featureUsingIt: String,
    val whyNeeded: String,
    val howToRevoke: String,
    val fallbackWhenDenied: String
) {
    OVERLAY(
        id = "SYSTEM_ALERT_WINDOW",
        title = "Display Over Other Apps (Overlay)",
        featureUsingIt = "Floating Gaming Panel & Smart Sidebar",
        whyNeeded = "Allows the booster's own floating mini-tools (timer, notes, calculator) to appear while you play.",
        howToRevoke = "Android Settings -> Apps -> Special app access -> Display over other apps.",
        fallbackWhenDenied = "All tools remain fully usable inside the main Universal Game Booster X app."
    ),
    DND_POLICY(
        id = "ACCESS_NOTIFICATION_POLICY",
        title = "Do Not Disturb Access",
        featureUsingIt = "One-Tap Game Preparation & Focus Timer",
        whyNeeded = "Lets you toggle Do Not Disturb during gaming or study sessions.",
        howToRevoke = "Android Settings -> Apps -> Special app access -> Do Not Disturb access.",
        fallbackWhenDenied = "Provides a direct shortcut to your system sound/DND settings panel."
    ),
    USAGE_STATS(
        id = "PACKAGE_USAGE_STATS",
        title = "Usage Access (Optional)",
        featureUsingIt = "Automatic Playtime Tracking & Background App Advisor",
        whyNeeded = "Measures session duration automatically without polling in the background.",
        howToRevoke = "Android Settings -> Apps -> Special app access -> Usage access.",
        fallbackWhenDenied = "Manual session timer in the Gaming Dashboard and Floating Panel continues working."
    ),
    CAMERA(
        id = "CAMERA",
        title = "Camera (Point-of-Need Only)",
        featureUsingIt = "QR/Barcode Scanner",
        whyNeeded = "Required only when scanning physical QR codes or barcodes.",
        howToRevoke = "Android Settings -> Apps -> Universal Game Booster X -> Permissions -> Camera.",
        fallbackWhenDenied = "Offline QR generator and manual text/URL tools remain available."
    ),
    POST_NOTIFICATIONS(
        id = "POST_NOTIFICATIONS",
        title = "Notifications (Android 13+)",
        featureUsingIt = "Pomodoro Timer Alerts & Foreground Floating Panel Service",
        whyNeeded = "Displays active timer progress and required foreground service controls.",
        howToRevoke = "Android Settings -> Apps -> Universal Game Booster X -> Notifications.",
        fallbackWhenDenied = "In-app visual timers and manual controls continue working."
    )
}

data class PermissionStatusItem(
    val type: BoosterPermissionType,
    val isGranted: Boolean
)

class PermissionCoordinator(private val context: Context) {

    fun canDrawOverlays(): Boolean = Settings.canDrawOverlays(context)

    fun hasDndAccess(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        return nm?.isNotificationPolicyAccessGranted == true
    }

    fun hasUsageStatsAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun inspectAllPermissions(): List<PermissionStatusItem> {
        return listOf(
            PermissionStatusItem(BoosterPermissionType.OVERLAY, canDrawOverlays()),
            PermissionStatusItem(BoosterPermissionType.DND_POLICY, hasDndAccess()),
            PermissionStatusItem(BoosterPermissionType.USAGE_STATS, hasUsageStatsAccess()),
            PermissionStatusItem(BoosterPermissionType.CAMERA, hasCameraPermission()),
            PermissionStatusItem(BoosterPermissionType.POST_NOTIFICATIONS, hasNotificationPermission())
        )
    }

    fun buildOverlaySettingsIntent(): Intent {
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun buildDndSettingsIntent(): Intent {
        return Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun buildUsageAccessIntent(): Intent {
        return Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
