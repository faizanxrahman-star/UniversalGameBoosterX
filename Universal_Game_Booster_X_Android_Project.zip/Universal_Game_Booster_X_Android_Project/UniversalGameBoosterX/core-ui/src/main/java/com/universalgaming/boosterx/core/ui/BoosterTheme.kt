package com.universalgaming.boosterx.core.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.universalgaming.boosterx.core.common.BoosterThemeMode

@Immutable
data class BoosterExtendedColors(
    val cardSurface: Color,
    val cardBorder: Color,
    val glowAccent: Color,
    val statusGood: Color,
    val statusWarning: Color,
    val statusCritical: Color,
    val isLightweightMode: Boolean
)

val LocalBoosterColors = staticCompositionLocalOf {
    BoosterExtendedColors(
        cardSurface = Color(0xFF0E1628),
        cardBorder = Color(0xFF1E3A5F),
        glowAccent = Color(0xFF00E5FF),
        statusGood = Color(0xFF00E676),
        statusWarning = Color(0xFFFFB300),
        statusCritical = Color(0xFFFF1744),
        isLightweightMode = false
    )
}

private val NeonBlueScheme = darkColorScheme(
    primary = Color(0xFF00E5FF),
    onPrimary = Color(0xFF001F26),
    secondary = Color(0xFF2979FF),
    tertiary = Color(0xFF00B0FF),
    background = Color(0xFF060A12),
    surface = Color(0xFF0E1628),
    onBackground = Color(0xFFE6F1FF),
    onSurface = Color(0xFFE6F1FF)
)

private val RgbCyberScheme = darkColorScheme(
    primary = Color(0xFFFF007F),
    onPrimary = Color(0xFF2B0014),
    secondary = Color(0xFF00F5D4),
    tertiary = Color(0xFF9B5DE5),
    background = Color(0xFF090614),
    surface = Color(0xFF150E2A),
    onBackground = Color(0xFFF7F0FF),
    onSurface = Color(0xFFF7F0FF)
)

private val AmoledBlackScheme = darkColorScheme(
    primary = Color(0xFF00E5FF),
    onPrimary = Color.Black,
    secondary = Color(0xFF00E676),
    tertiary = Color(0xFF40C4FF),
    background = Color(0xFF000000),
    surface = Color(0xFF070707),
    onBackground = Color(0xFFFFFFFF),
    onSurface = Color(0xFFE0E0E0)
)

private val CleanLightScheme = lightColorScheme(
    primary = Color(0xFF005AC1),
    onPrimary = Color.White,
    secondary = Color(0xFF006874),
    tertiary = Color(0xFF3F5AA9),
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF1E293B)
)

val BoosterTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun UniversalBoosterTheme(
    themeMode: BoosterThemeMode = BoosterThemeMode.NEON_BLUE,
    customAccentHex: Long = 0xFF00E5FF,
    lightweightMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme: ColorScheme = when (themeMode) {
        BoosterThemeMode.NEON_BLUE -> NeonBlueScheme
        BoosterThemeMode.RGB_CYBER -> RgbCyberScheme
        BoosterThemeMode.AMOLED_BLACK -> AmoledBlackScheme
        BoosterThemeMode.CLEAN_LIGHT -> CleanLightScheme
        BoosterThemeMode.CUSTOM_ACCENT -> NeonBlueScheme.copy(primary = Color(customAccentHex))
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = BoosterTypography,
        content = content
    )
}
