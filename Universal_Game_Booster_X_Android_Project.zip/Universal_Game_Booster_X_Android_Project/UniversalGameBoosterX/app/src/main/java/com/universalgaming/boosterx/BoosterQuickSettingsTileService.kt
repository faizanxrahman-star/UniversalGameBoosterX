package com.universalgaming.boosterx

import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.universalgaming.boosterx.feature.floatingpanel.FloatingGamingOverlayService

/**
 * Implements Section 30: Quick Settings Tile to open Universal Game Booster X
 * or toggle the supported Floating Gaming Panel.
 */
@RequiresApi(Build.VERSION_CODES.N)
class BoosterQuickSettingsTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = if (Settings.canDrawOverlays(this@BoosterQuickSettingsTileService)) {
                Tile.STATE_ACTIVE
            } else {
                Tile.STATE_INACTIVE
            }
            label = "Booster X HUD"
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        if (Settings.canDrawOverlays(this)) {
            val serviceIntent = Intent(this, FloatingGamingOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } else {
            val launchIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivityAndCollapse(launchIntent)
        }
    }
}
