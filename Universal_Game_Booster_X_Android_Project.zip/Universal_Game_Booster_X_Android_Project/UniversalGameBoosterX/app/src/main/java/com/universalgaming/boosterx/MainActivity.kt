package com.universalgaming.boosterx

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.universalgaming.boosterx.core.compatibility.SmartCompatibilityEngine
import com.universalgaming.boosterx.core.data.PreferencesRepository
import com.universalgaming.boosterx.core.permissions.PermissionCoordinator
import com.universalgaming.boosterx.core.ui.HonestMetricCard
import com.universalgaming.boosterx.core.ui.UniversalBoosterTheme
import com.universalgaming.boosterx.feature.battery.BatteryThermalAssistant
import com.universalgaming.boosterx.feature.floatingpanel.FloatingGamingOverlayService
import com.universalgaming.boosterx.feature.home.HomeDashboardScreen
import com.universalgaming.boosterx.feature.home.HomeDashboardSnapshot
import com.universalgaming.boosterx.feature.network.NetworkDiagnosticsEngine
import com.universalgaming.boosterx.feature.performance.RealPerformanceCollector
import com.universalgaming.boosterx.feature.storage.SafStorageAndDuplicateFinder
import kotlinx.coroutines.launch

enum class PrimaryDestination(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Default.Home),
    GAMES("games", "Games", Icons.Default.SportsEsports),
    POPUP_HUB("popup_hub", "Popup Hub", Icons.Default.Layers),
    DEVICE_HEALTH("device_health", "Health", Icons.Default.Devices),
    TOOLS("tools", "Tools", Icons.Default.Build),
    SETTINGS("settings", "Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val prefsRepo = PreferencesRepository(applicationContext)
        val permCoordinator = PermissionCoordinator(applicationContext)
        val compatEngine = SmartCompatibilityEngine(applicationContext, permCoordinator)
        val perfCollector = RealPerformanceCollector(applicationContext)
        val batteryAssistant = BatteryThermalAssistant(applicationContext)
        val storageFinder = SafStorageAndDuplicateFinder(applicationContext)
        val networkEngine = NetworkDiagnosticsEngine(applicationContext)

        setContent {
            val prefs by prefsRepo.preferencesFlow.collectAsState(
                initial = com.universalgaming.boosterx.core.data.UserPreferencesState()
            )
            val scope = rememberCoroutineScope()
            var currentTab by remember { mutableStateOf(PrimaryDestination.HOME) }

            val sysMetrics = remember { perfCollector.sampleCurrentMetrics() }
            val batterySnap = remember { batteryAssistant.readBatteryTelemetry() }
            val storageSnap = remember { storageFinder.getStorageOverview() }
            val netSummary = remember { networkEngine.getConnectionSummary() }

            UniversalBoosterTheme(
                themeMode = prefs.themeMode,
                customAccentHex = prefs.customAccentHex,
                lightweightMode = prefs.isLightweightMode
            ) {
                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            PrimaryDestination.entries.forEach { dest ->
                                NavigationBarItem(
                                    selected = currentTab == dest,
                                    onClick = { currentTab = dest },
                                    icon = { Icon(dest.icon, contentDescription = dest.label) },
                                    label = { Text(dest.label) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    when (currentTab) {
                        PrimaryDestination.HOME -> {
                            HomeDashboardScreen(
                                snapshot = HomeDashboardSnapshot(
                                    activePreset = prefs.dashboardPreset,
                                    batteryPct = batterySnap.levelPct,
                                    batteryTempC = batterySnap.temperatureCelsius,
                                    thermalStatusLabel = sysMetrics.thermalStatusLabel,
                                    availableRamMb = sysMetrics.availableRamMb,
                                    totalRamMb = sysMetrics.totalRamMb,
                                    freeStorageGb = "${"%.2f".format(storageSnap.freeBytes / 1_073_741_824.0)} GB",
                                    networkStatusLabel = "${netSummary.second} (${if (netSummary.first) "Online" else "Offline"})",
                                    displayRefreshHz = sysMetrics.displayRefreshRateHz,
                                    favoriteGameCount = 0,
                                    overlayGranted = permCoordinator.canDrawOverlays(),
                                    visibleCardIds = prefs.visibleDashboardCardsCsv.split(",")
                                ),
                                onPresetSelected = { scope.launch { prefsRepo.setDashboardPreset(it) } },
                                onPrepareGameClick = { currentTab = PrimaryDestination.GAMES },
                                onToggleOverlayPanel = {
                                    if (permCoordinator.canDrawOverlays()) {
                                        val svc = Intent(this, FloatingGamingOverlayService::class.java)
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            startForegroundService(svc)
                                        } else {
                                            startService(svc)
                                        }
                                    } else {
                                        startActivity(permCoordinator.buildOverlaySettingsIntent())
                                    }
                                },
                                onResetLayoutClick = { scope.launch { prefsRepo.restoreDefaultDashboard() } },
                                modifier = Modifier.padding(innerPadding)
                            )
                        }
                        else -> {
                            val caps = remember { compatEngine.evaluateAllCapabilities() }
                            androidx.compose.foundation.lazy.LazyColumn(
                                modifier = Modifier.padding(innerPadding).padding(16.dp),
                                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)
                            ) {
                                item {
                                    Text(
                                        text = "${currentTab.label} Module",
                                        style = androidx.compose.material3.MaterialTheme.typography.headlineMedium
                                    )
                                }
                                items(caps.size) { index ->
                                    val cap = caps[index]
                                    HonestMetricCard(
                                        title = cap.featureName,
                                        valueText = cap.supportLevel.name,
                                        sourceLabel = cap.requiredApiDescription,
                                        unavailableReason = cap.knownLimitations
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
