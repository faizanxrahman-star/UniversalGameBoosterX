package com.universalgaming.boosterx

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

/**
 * Implements Section 30: Home Screen Widget respecting Android widget refresh limits.
 */
class BoosterSummaryWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (widgetId in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.widget_booster_summary)
            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }
}
