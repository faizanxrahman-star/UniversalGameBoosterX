plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.universalgaming.boosterx"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.universalgaming.boosterx"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(project(":core-common"))
    implementation(project(":core-ui"))
    implementation(project(":core-data"))
    implementation(project(":core-permissions"))
    implementation(project(":core-compatibility"))
    implementation(project(":feature-home"))
    implementation(project(":feature-games"))
    implementation(project(":feature-game-profiles"))
    implementation(project(":feature-performance"))
    implementation(project(":feature-network"))
    implementation(project(":feature-floating-panel"))
    implementation(project(":feature-popup-hub"))
    implementation(project(":feature-device-health"))
    implementation(project(":feature-battery"))
    implementation(project(":feature-storage"))
    implementation(project(":feature-tools"))
    implementation(project(":feature-qr"))
    implementation(project(":feature-notes"))
    implementation(project(":feature-file-transfer"))
    implementation(project(":feature-privacy"))
    implementation(project(":feature-backup"))
    implementation(project(":feature-settings"))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.service)
    implementation(libs.androidx.work.runtime.ktx)
    testImplementation(libs.junit)
}
