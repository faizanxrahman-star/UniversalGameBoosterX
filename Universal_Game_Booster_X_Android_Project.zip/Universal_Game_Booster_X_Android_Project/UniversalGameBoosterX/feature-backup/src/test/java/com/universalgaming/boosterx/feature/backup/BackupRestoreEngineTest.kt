package com.universalgaming.boosterx.feature.backup

import com.universalgaming.boosterx.core.common.AppResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupRestoreEngineTest {
    private val engine = BackupRestoreEngine()

    @Test
    fun `valid backup detects conflicting profile IDs accurately`() {
        val json = engine.createBackupJson(
            profileIds = listOf("performance", "custom_competitive"),
            notesTitles = listOf("Sensitivity settings"),
            snippetTitles = listOf("Squad ID"),
            routineNames = listOf("Night Ranked")
        )
        val preview = engine.validateAndPreviewBackup(json, setOf("performance", "balanced"))
        assertTrue(preview is AppResult.Success)
        val data = (preview as AppResult.Success).data
        assertEquals(listOf("performance"), data.conflictingProfileIds)
        assertEquals(2, data.gameProfileCount)
    }
}
