package com.universalgaming.boosterx.feature.backup

import com.universalgaming.boosterx.core.common.AppResult
import org.json.JSONArray
import org.json.JSONObject

data class BackupPreviewSummary(
    val schemaVersion: Int,
    val exportedAtEpochMs: Long,
    val gameProfileCount: Int,
    val noteCount: Int,
    val snippetCount: Int,
    val routineCount: Int,
    val conflictingProfileIds: List<String>
)

/**
 * Implements Section 29 & Section 41:
 * Safe JSON validation, size limit check, conflict preview before import,
 * and zero arbitrary code execution.
 */
class BackupRestoreEngine {

    companion object {
        const val CURRENT_BACKUP_SCHEMA = 1
        const val MAX_BACKUP_BYTES = 10 * 1024 * 1024 // 10 MB safety ceiling
    }

    fun createBackupJson(
        profileIds: List<String>,
        notesTitles: List<String>,
        snippetTitles: List<String>,
        routineNames: List<String>,
        nowEpochMs: Long = System.currentTimeMillis()
    ): String {
        val root = JSONObject()
        root.put("app", "com.universalgaming.boosterx")
        root.put("schemaVersion", CURRENT_BACKUP_SCHEMA)
        root.put("exportedAtEpochMs", nowEpochMs)
        root.put("profiles", JSONArray(profileIds))
        root.put("notes", JSONArray(notesTitles))
        root.put("snippets", JSONArray(snippetTitles))
        root.put("routines", JSONArray(routineNames))
        return root.toString(2)
    }

    fun validateAndPreviewBackup(
        rawJson: String,
        existingProfileIds: Set<String>
    ): AppResult<BackupPreviewSummary> {
        val byteLen = rawJson.toByteArray(Charsets.UTF_8).size
        if (byteLen == 0 || byteLen > MAX_BACKUP_BYTES) {
            return AppResult.Error(
                whatFailed = "Backup validation failed",
                whyFailed = "File size ($byteLen bytes) is empty or exceeds the 10 MB safety limit.",
                nextAction = "Select a valid Universal Game Booster X .json backup file."
            )
        }

        return try {
            val obj = JSONObject(rawJson)
            val appId = obj.optString("app", "")
            val schema = obj.optInt("schemaVersion", -1)
            if (appId != "com.universalgaming.boosterx" || schema != CURRENT_BACKUP_SCHEMA) {
                return AppResult.Error(
                    whatFailed = "Incompatible backup file",
                    whyFailed = "Header app='$appId' or schemaVersion=$schema does not match v$CURRENT_BACKUP_SCHEMA.",
                    nextAction = "Choose a backup exported by Universal Game Booster X."
                )
            }

            val profilesArr = obj.optJSONArray("profiles") ?: JSONArray()
            val importedProfiles = mutableListOf<String>()
            for (i in 0 until profilesArr.length()) {
                importedProfiles.add(profilesArr.getString(i))
            }

            val conflicts = importedProfiles.filter { it in existingProfileIds }

            AppResult.Success(
                BackupPreviewSummary(
                    schemaVersion = schema,
                    exportedAtEpochMs = obj.optLong("exportedAtEpochMs", 0L),
                    gameProfileCount = importedProfiles.size,
                    noteCount = obj.optJSONArray("notes")?.length() ?: 0,
                    snippetCount = obj.optJSONArray("snippets")?.length() ?: 0,
                    routineCount = obj.optJSONArray("routines")?.length() ?: 0,
                    conflictingProfileIds = conflicts
                )
            )
        } catch (e: Exception) {
            AppResult.Error(
                whatFailed = "Corrupted JSON backup file",
                whyFailed = e.localizedMessage ?: "Syntax error in JSON payload.",
                nextAction = "Verify the backup file was not truncated and retry."
            )
        }
    }
}
