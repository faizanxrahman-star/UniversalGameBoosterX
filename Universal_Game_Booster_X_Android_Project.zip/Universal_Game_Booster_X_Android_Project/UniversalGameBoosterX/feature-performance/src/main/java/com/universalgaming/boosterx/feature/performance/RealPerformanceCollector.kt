package com.universalgaming.boosterx.feature.performance

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Debug
import android.os.PowerManager
import android.view.WindowManager

data class RealSystemMetrics(
    val availableRamMb: Long,
    val totalRamMb: Long,
    val lowMemoryFlag: Boolean,
    val boosterAppPssKb: Int,
    val cpuAbiList: List<String>,
    val hardwareSocModel: String,
    val thermalStatusLabel: String,
    val displayRefreshRateHz: Int,
    val fpsLimitationNotice: String
)

class RealPerformanceCollector(private val context: Context) {

    fun sampleCurrentMetrics(): RealSystemMetrics {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val myMemInfo = Debug.MemoryInfo()
        Debug.getMemoryInfo(myMemInfo)

        val thermalLabel = readSupportedThermalStatus()
        val refreshHz = readDisplayRefreshRateHz()

        val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim()
        } else {
            Build.HARDWARE ?: "Unknown SoC"
        }

        return RealSystemMetrics(
            availableRamMb = memInfo.availMem / (1024 * 1024),
            totalRamMb = memInfo.totalMem / (1024 * 1024),
            lowMemoryFlag = memInfo.lowMemory,
            boosterAppPssKb = myMemInfo.totalPss,
            cpuAbiList = Build.SUPPORTED_ABIS.toList(),
            hardwareSocModel = soc,
            thermalStatusLabel = thermalLabel,
            displayRefreshRateHz = refreshHz,
            fpsLimitationNotice = "Android isolates third-party game rendering pipelines. Display refresh rate (${refreshHz} Hz) is real; use Lag Markers in the Floating Panel to log frame drops honestly."
        )
    }

    private fun readSupportedThermalStatus(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return "Requires Android 10+ (API 29) — Using Battery Sensor Fallback"
        }
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return "Unavailable"
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "None (Cool)"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light Warmth"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate Warmth"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe (Throttling Likely)"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical Heat — Pause Gaming"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency Thermal Limit"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown Imminent"
            else -> "Unknown"
        }
    }

    private fun readDisplayRefreshRateHz(): Int {
        return try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            @Suppress("DEPRECATION")
            val rate = wm?.defaultDisplay?.refreshRate ?: 60f
            rate.toInt()
        } catch (_: Exception) {
            60
        }
    }
}
