package com.universalgaming.boosterx.feature.notes

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.PersistableBundle

/**
 * Implements Section 13: Privacy-conscious text & snippet organizer.
 * Respects Android 10+ background clipboard restrictions and marks sensitive copies
 * with ClipDescription.EXTRA_IS_SENSITIVE on Android 13+.
 */
class ClipboardTextVaultManager(private val context: Context) {

    fun copySnippetToClipboard(label: String, text: String, isSensitive: Boolean): Boolean {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return false
        val clip = ClipData.newPlainText(label, text)
        if (isSensitive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean("android.content.extra.IS_SENSITIVE", true)
            }
        }
        cm.setPrimaryClip(clip)
        return true
    }

    fun getClipboardLimitationExplanation(): String {
        return "Android 10+ restricts background clipboard monitoring to protect your passwords and OTPs. Universal Game Booster X never reads your clipboard in the background — only snippets you explicitly save or paste while the app is open are stored."
    }
}
