package com.universalgaming.boosterx.core.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "game_entries",
    indices = [Index(value = ["packageName"], unique = true)]
)
data class GameEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appName: String,
    val versionName: String?,
    val category: String = "Uncategorized",
    val isFavorite: Boolean = false,
    val isManuallyAdded: Boolean = false,
    val lastPlayedEpochMs: Long? = null,
    val totalRecordedPlaytimeMs: Long = 0L,
    val selectedProfileId: String = "balanced",
    val userNotes: String = ""
)

@Entity(tableName = "game_profiles")
data class GameProfileEntity(
    @PrimaryKey val profileId: String,
    val profileName: String,
    val pollingIntervalMs: Long,
    val showBatteryMetric: Boolean,
    val showThermalMetric: Boolean,
    val showNetworkMetric: Boolean,
    val offerDndShortcut: Boolean,
    val offerBrightnessShortcut: Boolean,
    val autoOpenFloatingPanel: Boolean,
    val reduceBoosterAnimations: Boolean
)

@Entity(tableName = "session_records")
data class SessionRecordEntity(
    @PrimaryKey(autoGenerate = true) val sessionId: Long = 0,
    val packageName: String,
    val gameName: String,
    val profileId: String,
    val startTimeEpochMs: Long,
    val endTimeEpochMs: Long?,
    val durationMs: Long,
    val startBatteryPct: Int?,
    val endBatteryPct: Int?,
    val maxBatteryTempCelsius: Float?,
    val thermalStatusSummary: String,
    val avgPingMs: Long?,
    val userNotes: String = ""
)

@Entity(tableName = "lag_markers")
data class LagMarkerEntity(
    @PrimaryKey(autoGenerate = true) val markerId: Long = 0,
    val sessionId: Long,
    val timestampEpochMs: Long,
    val batteryPctAtMarker: Int?,
    val batteryTempCelsius: Float?,
    val thermalStatusCode: Int?,
    val availableRamMb: Long?,
    val userNote: String
)

@Entity(tableName = "network_test_records")
data class NetworkTestRecordEntity(
    @PrimaryKey(autoGenerate = true) val testId: Long = 0,
    val timestampEpochMs: Long,
    val targetEndpoint: String,
    val connectionType: String,
    val latencyMs: Long?,
    val jitterMs: Long?,
    val packetLossPct: Int?,
    val dnsLookupMs: Long?,
    val isReachable: Boolean,
    val notes: String
)

@Entity(tableName = "user_notes")
data class UserNoteEntity(
    @PrimaryKey(autoGenerate = true) val noteId: Long = 0,
    val title: String,
    val body: String,
    val category: String = "General",
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val updatedAtEpochMs: Long
)

@Entity(tableName = "text_snippets")
data class TextSnippetEntity(
    @PrimaryKey(autoGenerate = true) val snippetId: Long = 0,
    val title: String,
    val content: String,
    val category: String = "Quick Copy",
    val isPinned: Boolean = false,
    val isSensitiveLocked: Boolean = false,
    val createdAtEpochMs: Long
)

@Entity(tableName = "workspace_profiles")
data class WorkspaceProfileEntity(
    @PrimaryKey val workspaceId: String,
    val name: String,
    val enabledMiniToolsCsv: String,
    val panelOpacity: Float,
    val isCompactMode: Boolean,
    val anchorEdge: String,
    val favoriteShortcutsPackagesCsv: String
)

@Entity(tableName = "gaming_routines")
data class GamingRoutineEntity(
    @PrimaryKey(autoGenerate = true) val routineId: Long = 0,
    val routineName: String,
    val targetGamePackage: String?,
    val checkBatteryFirst: Boolean,
    val runNetworkTest: Boolean,
    val startSessionTimer: Boolean,
    val applyProfileId: String,
    val promptDndShortcut: Boolean,
    val launchGameAtEnd: Boolean
)

@Entity(tableName = "storage_observations")
data class StorageObservationEntity(
    @PrimaryKey(autoGenerate = true) val observationId: Long = 0,
    val timestampEpochMs: Long,
    val freeBytes: Long,
    val totalBytes: Long,
    val appSpecificBytes: Long
)
