package com.universalgaming.boosterx.core.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        GameEntryEntity::class,
        GameProfileEntity::class,
        SessionRecordEntity::class,
        LagMarkerEntity::class,
        NetworkTestRecordEntity::class,
        UserNoteEntity::class,
        TextSnippetEntity::class,
        WorkspaceProfileEntity::class,
        GamingRoutineEntity::class,
        StorageObservationEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class BoosterDatabase : RoomDatabase() {
    abstract fun boosterDao(): BoosterDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `storage_observations` (" +
                        "`observationId` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`timestampEpochMs` INTEGER NOT NULL, " +
                        "`freeBytes` INTEGER NOT NULL, " +
                        "`totalBytes` INTEGER NOT NULL, " +
                        "`appSpecificBytes` INTEGER NOT NULL)"
                )
            }
        }

        @Volatile
        private var INSTANCE: BoosterDatabase? = null

        fun getInstance(context: Context): BoosterDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BoosterDatabase::class.java,
                    "universal_game_booster_x.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
