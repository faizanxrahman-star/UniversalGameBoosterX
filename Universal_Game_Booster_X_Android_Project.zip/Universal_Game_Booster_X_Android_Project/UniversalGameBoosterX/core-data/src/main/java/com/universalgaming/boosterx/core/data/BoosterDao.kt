package com.universalgaming.boosterx.core.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BoosterDao {
    // Games
    @Query("SELECT * FROM game_entries ORDER BY isFavorite DESC, appName ASC")
    fun observeAllGames(): Flow<List<GameEntryEntity>>

    @Query("SELECT * FROM game_entries WHERE packageName = :pkg LIMIT 1")
    suspend fun getGameByPackage(pkg: String): GameEntryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGame(game: GameEntryEntity): Long

    @Query("DELETE FROM game_entries WHERE packageName = :pkg")
    suspend fun removeGameFromLibrary(pkg: String)

    // Profiles
    @Query("SELECT * FROM game_profiles ORDER BY profileName ASC")
    fun observeProfiles(): Flow<List<GameProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: GameProfileEntity)

    // Sessions & Lag Markers
    @Query("SELECT * FROM session_records ORDER BY startTimeEpochMs DESC")
    fun observeSessions(): Flow<List<SessionRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: SessionRecordEntity): Long

    @Query("DELETE FROM session_records WHERE sessionId = :id")
    suspend fun deleteSession(id: Long)

    @Query("DELETE FROM session_records")
    suspend fun clearAllSessions()

    @Query("SELECT * FROM lag_markers WHERE sessionId = :sessionId ORDER BY timestampEpochMs ASC")
    fun observeLagMarkers(sessionId: Long): Flow<List<LagMarkerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLagMarker(marker: LagMarkerEntity): Long

    // Network Tests
    @Query("SELECT * FROM network_test_records ORDER BY timestampEpochMs DESC LIMIT 100")
    fun observeNetworkTests(): Flow<List<NetworkTestRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNetworkTest(record: NetworkTestRecordEntity): Long

    @Query("DELETE FROM network_test_records")
    suspend fun clearNetworkHistory()

    // Notes
    @Query("SELECT * FROM user_notes ORDER BY isPinned DESC, updatedAtEpochMs DESC")
    fun observeNotes(): Flow<List<UserNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNote(note: UserNoteEntity): Long

    @Delete
    suspend fun deleteNote(note: UserNoteEntity)

    // Clipboard Vault Snippets
    @Query("SELECT * FROM text_snippets ORDER BY isPinned DESC, createdAtEpochMs DESC")
    fun observeSnippets(): Flow<List<TextSnippetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSnippet(snippet: TextSnippetEntity): Long

    @Delete
    suspend fun deleteSnippet(snippet: TextSnippetEntity)

    @Query("DELETE FROM text_snippets")
    suspend fun clearAllSnippets()

    // Workspace Profiles & Routines
    @Query("SELECT * FROM workspace_profiles")
    fun observeWorkspaceProfiles(): Flow<List<WorkspaceProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorkspaceProfile(profile: WorkspaceProfileEntity)

    @Query("SELECT * FROM gaming_routines ORDER BY routineName ASC")
    fun observeRoutines(): Flow<List<GamingRoutineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRoutine(routine: GamingRoutineEntity): Long

    // Storage Trend Observations
    @Query("SELECT * FROM storage_observations ORDER BY timestampEpochMs DESC LIMIT 60")
    fun observeStorageTrends(): Flow<List<StorageObservationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStorageObservation(obs: StorageObservationEntity)

    @Query("DELETE FROM storage_observations")
    suspend fun clearStorageObservations()
}
