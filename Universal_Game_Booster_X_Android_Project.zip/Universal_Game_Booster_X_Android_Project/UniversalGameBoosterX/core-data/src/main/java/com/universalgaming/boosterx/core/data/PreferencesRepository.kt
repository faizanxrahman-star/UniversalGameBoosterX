package com.universalgaming.boosterx.core.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.universalgaming.boosterx.core.common.AppLanguage
import com.universalgaming.boosterx.core.common.BoosterThemeMode
import com.universalgaming.boosterx.core.common.DashboardPreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "booster_x_preferences")

data class UserPreferencesState(
    val themeMode: BoosterThemeMode = BoosterThemeMode.NEON_BLUE,
    val customAccentHex: Long = 0xFF00E5FF,
    val language: AppLanguage = AppLanguage.HINGLISH,
    val dashboardPreset: DashboardPreset = DashboardPreset.GAMING,
    val isCompactDashboard: Boolean = false,
    val isLightweightMode: Boolean = false,
    val visibleDashboardCardsCsv: String = "games,prepare,battery,thermal,storage,network,tools,compatibility",
    val isAppLockEnabled: Boolean = false,
    val isBiometricEnabled: Boolean = false,
    val storageHistoryEnabled: Boolean = true
)

class PreferencesRepository(private val context: Context) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val CUSTOM_ACCENT = longPreferencesKey("custom_accent_hex")
        val LANGUAGE = stringPreferencesKey("app_language")
        val DASHBOARD_PRESET = stringPreferencesKey("dashboard_preset")
        val COMPACT_DASHBOARD = booleanPreferencesKey("compact_dashboard")
        val LIGHTWEIGHT_MODE = booleanPreferencesKey("lightweight_mode")
        val VISIBLE_CARDS = stringPreferencesKey("visible_cards_csv")
        val APP_LOCK_ENABLED = booleanPreferencesKey("app_lock_enabled")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val STORAGE_HISTORY_ENABLED = booleanPreferencesKey("storage_history_enabled")
    }

    val preferencesFlow: Flow<UserPreferencesState> = context.dataStore.data.map { prefs ->
        UserPreferencesState(
            themeMode = BoosterThemeMode.entries.find { it.id == prefs[Keys.THEME_MODE] }
                ?: BoosterThemeMode.NEON_BLUE,
            customAccentHex = prefs[Keys.CUSTOM_ACCENT] ?: 0xFF00E5FFL,
            language = AppLanguage.entries.find { it.code == prefs[Keys.LANGUAGE] }
                ?: AppLanguage.HINGLISH,
            dashboardPreset = DashboardPreset.entries.find { it.id == prefs[Keys.DASHBOARD_PRESET] }
                ?: DashboardPreset.GAMING,
            isCompactDashboard = prefs[Keys.COMPACT_DASHBOARD] ?: false,
            isLightweightMode = prefs[Keys.LIGHTWEIGHT_MODE] ?: false,
            visibleDashboardCardsCsv = prefs[Keys.VISIBLE_CARDS]
                ?: "games,prepare,battery,thermal,storage,network,tools,compatibility",
            isAppLockEnabled = prefs[Keys.APP_LOCK_ENABLED] ?: false,
            isBiometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
            storageHistoryEnabled = prefs[Keys.STORAGE_HISTORY_ENABLED] ?: true
        )
    }

    suspend fun setThemeMode(mode: BoosterThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.id }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setDashboardPreset(preset: DashboardPreset) {
        context.dataStore.edit { it[Keys.DASHBOARD_PRESET] = preset.id }
    }

    suspend fun setLightweightMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.LIGHTWEIGHT_MODE] = enabled }
    }

    suspend fun updateVisibleCards(csv: String) {
        context.dataStore.edit { it[Keys.VISIBLE_CARDS] = csv }
    }

    suspend fun restoreDefaultDashboard() {
        context.dataStore.edit {
            it[Keys.VISIBLE_CARDS] = "games,prepare,battery,thermal,storage,network,tools,compatibility"
            it[Keys.COMPACT_DASHBOARD] = false
            it[Keys.DASHBOARD_PRESET] = DashboardPreset.GAMING.id
        }
    }
}
