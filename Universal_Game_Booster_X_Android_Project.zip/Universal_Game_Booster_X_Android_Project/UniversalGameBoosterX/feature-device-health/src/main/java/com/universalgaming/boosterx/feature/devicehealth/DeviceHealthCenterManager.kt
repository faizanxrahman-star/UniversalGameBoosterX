package com.universalgaming.boosterx.feature.devicehealth

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DeviceHealthReport(
    val generatedAtIso: String,
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val apiLevel: Int,
    val supportedAbis: String,
    val sensorNames: List<String>,
    val troubleshootingTips: List<String>
)

class DeviceHealthCenterManager(private val context: Context) {

    fun generateLocalDiagnosticReport(): DeviceHealthReport {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensors = sm?.getSensorList(Sensor.TYPE_ALL)?.map { it.name } ?: emptyList()
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

        return DeviceHealthReport(
            generatedAtIso = timestamp,
            manufacturer = Build.MANUFACTURER ?: "Unknown",
            model = Build.MODEL ?: "Unknown",
            androidVersion = Build.VERSION.RELEASE ?: "Unknown",
            apiLevel = Build.VERSION.SDK_INT,
            supportedAbis = Build.SUPPORTED_ABIS.joinToString(", "),
            sensorNames = sensors,
            troubleshootingTips = listOf(
                "If games stutter after 15 minutes, check Battery & Thermal history for thermal throttling (>= 41°C).",
                "Avoid charging with high-wattage fast chargers during graphically intensive 60/120Hz gaming.",
                "Do not use aggressive 'RAM killer' apps — Android automatically caches frequently used game assets in RAM."
            )
        )
    }
}
