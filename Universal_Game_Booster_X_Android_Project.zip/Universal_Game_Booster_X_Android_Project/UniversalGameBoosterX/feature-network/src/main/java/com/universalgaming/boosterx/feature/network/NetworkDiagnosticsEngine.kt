package com.universalgaming.boosterx.feature.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.system.measureTimeMillis

data class NetworkDiagnosticReport(
    val isConnected: Boolean,
    val transportType: String,
    val testedEndpoint: String,
    val samplesMs: List<Long>,
    val avgLatencyMs: Long?,
    val jitterMs: Long?,
    val packetLossPct: Int,
    val dnsResolutionMs: Long?,
    val honestyDisclaimer: String
)

/**
 * Implements Section 9: Genuine TCP handshake latency, jitter, packet loss, and DNS resolution tests.
 * Never claims to change a game's server routing or guarantee lower in-game ping.
 */
class NetworkDiagnosticsEngine(private val context: Context) {

    fun getConnectionSummary(): Pair<Boolean, String> {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false to "Unavailable"
        val activeNet = cm.activeNetwork ?: return false to "Offline"
        val caps = cm.getNetworkCapabilities(activeNet) ?: return false to "Offline"
        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected (Other)"
        }
        return true to type
    }

    suspend fun runLatencyAndDnsTest(
        host: String = "1.1.1.1",
        port: Int = 53,
        dnsHostToResolve: String = "one.one.one.one",
        attempts: Int = 4,
        timeoutMs: Int = 1500
    ): NetworkDiagnosticReport = withContext(Dispatchers.IO) {
        val (connected, transport) = getConnectionSummary()
        if (!connected) {
            return@withContext NetworkDiagnosticReport(
                isConnected = false,
                transportType = "Offline",
                testedEndpoint = "$host:$port",
                samplesMs = emptyList(),
                avgLatencyMs = null,
                jitterMs = null,
                packetLossPct = 100,
                dnsResolutionMs = null,
                honestyDisclaimer = "Device is offline. Online speed/latency tests require an active connection."
            )
        }

        val dnsMs = try {
            measureTimeMillis {
                InetAddress.getByName(dnsHostToResolve)
            }
        } catch (_: Exception) {
            null
        }

        val samples = mutableListOf<Long>()
        var failures = 0

        repeat(attempts.coerceIn(1, 10)) {
            try {
                val rtt = measureTimeMillis {
                    Socket().use { socket ->
                        socket.connect(InetSocketAddress(host, port), timeoutMs)
                    }
                }
                samples.add(rtt)
            } catch (_: Exception) {
                failures++
            }
        }

        val avg = if (samples.isNotEmpty()) samples.average().toLong() else null
        val jitter = if (samples.size >= 2) {
            samples.zipWithNext { a, b -> abs(b - a) }.average().toLong()
        } else {
            0L
        }
        val lossPct = ((failures.toDouble() / attempts.toDouble()) * 100.0).toInt()

        NetworkDiagnosticReport(
            isConnected = true,
            transportType = transport,
            testedEndpoint = "$host:$port (DNS: $dnsHostToResolve)",
            samplesMs = samples,
            avgLatencyMs = avg,
            jitterMs = jitter,
            packetLossPct = lossPct,
            dnsResolutionMs = dnsMs,
            honestyDisclaimer = "Ping depends on physical server distance, ISP routing, and congestion. This test measures reachability to $host:$port and cannot alter game servers."
        )
    }
}
