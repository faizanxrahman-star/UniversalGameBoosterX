package com.universalgaming.boosterx.core.compatibility

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import com.universalgaming.boosterx.core.permissions.PermissionCoordinator

enum class SupportLevel {
    FULLY_SUPPORTED,
    PARTIALLY_SUPPORTED,
    UNAVAILABLE
}

enum class DeviceOemFamily(val displayName: String, val multitaskingNotes: String) {
    SAMSUNG("Samsung (One UI)", "Supports Multi Window, Pop-up view, and Samsung DeX on eligible models."),
    XIAOMI_POCO_REDMI("Xiaomi / Redmi / POCO (MIUI / HyperOS)", "Supports Floating Windows & Sidebar via native system settings; background autostart may require manual toggle."),
    OPPO("OPPO (ColorOS)", "Supports Flexible Windows and Smart Sidebar on compatible ColorOS versions."),
    REALME("Realme (Realme UI)", "Supports Mini Window / Flexible Window on eligible Realme UI devices."),
    VIVO_IQOO("Vivo / iQOO (FuntouchOS / OriginOS)", "Supports Small Window mode and Ultra Game Mode via system settings."),
    ONEPLUS("OnePlus (OxygenOS)", "Supports Floating Window and Split View on OxygenOS."),
    MOTOROLA("Motorola (MyUX / Hello UI)", "Supports Android standard split-screen and Ready For / Smart Connect on eligible models."),
    GOOGLE_PIXEL("Google Pixel (Pixel UI)", "Supports standard Android Split Screen and Freeform windows (when enabled in Developer Options / Desktop mode)."),
    NOKIA_HMD("Nokia / HMD (Stock Android)", "Supports standard Android multi-window split-screen."),
    GENERIC_ANDROID("Generic Android OEM", "Uses standard Android AOSP multi-window and capability APIs.")
}

data class CapabilityEntry(
    val featureId: String,
    val featureName: String,
    val minSdkRequired: Int,
    val currentSdk: Int,
    val requiredApiDescription: String,
    val requiredPermission: String,
    val oemDependencyNotes: String,
    val supportLevel: SupportLevel,
    val requiresUserSettingsAction: Boolean,
    val requiresReboot: Boolean,
    val knownLimitations: String,
    val fallbackBehavior: String
)

class SmartCompatibilityEngine(
    private val context: Context,
    private val permissionCoordinator: PermissionCoordinator
) {
    fun detectOemFamily(manufacturerRaw: String = Build.MANUFACTURER): DeviceOemFamily {
        val m = manufacturerRaw.lowercase()
        return when {
            m.contains("samsung") -> DeviceOemFamily.SAMSUNG
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") -> DeviceOemFamily.XIAOMI_POCO_REDMI
            m.contains("oppo") -> DeviceOemFamily.OPPO
            m.contains("realme") -> DeviceOemFamily.REALME
            m.contains("vivo") || m.contains("iqoo") -> DeviceOemFamily.VIVO_IQOO
            m.contains("oneplus") -> DeviceOemFamily.ONEPLUS
            m.contains("motorola") || m.contains("lenovo") -> DeviceOemFamily.MOTOROLA
            m.contains("google") -> DeviceOemFamily.GOOGLE_PIXEL
            m.contains("nokia") || m.contains("hmd") -> DeviceOemFamily.NOKIA_HMD
            else -> DeviceOemFamily.GENERIC_ANDROID
        }
    }

    fun isFreeformWindowManagementSupported(): Boolean {
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
    }

    fun isFlashlightAvailable(): Boolean {
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) return false
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return false
            cm.cameraIdList.any { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) {
            false
        }
    }

    fun evaluateAllCapabilities(sdkInt: Int = Build.VERSION.SDK_INT): List<CapabilityEntry> {
        val oem = detectOemFamily()
        val freeform = isFreeformWindowManagementSupported()
        val overlayGranted = permissionCoordinator.canDrawOverlays()

        return listOf(
            CapabilityEntry(
                featureId = "booster_floating_overlay",
                featureName = "System A: Booster Floating Gaming Panel",
                minSdkRequired = 26,
                currentSdk = sdkInt,
                requiredApiDescription = "WindowManager TYPE_APPLICATION_OVERLAY",
                requiredPermission = "SYSTEM_ALERT_WINDOW",
                oemDependencyNotes = "Universal across Android 8.0+ (except Android Go editions that disable overlays).",
                supportLevel = if (overlayGranted) SupportLevel.FULLY_SUPPORTED else SupportLevel.PARTIALLY_SUPPORTED,
                requiresUserSettingsAction = !overlayGranted,
                requiresReboot = false,
                knownLimitations = "Renders Universal Game Booster X's own tools only. Cannot embed third-party apps.",
                fallbackBehavior = "Open tools directly inside the main app dashboard."
            ),
            CapabilityEntry(
                featureId = "native_freeform_popup",
                featureName = "System B: Third-Party App Freeform Popup Windows",
                minSdkRequired = 28,
                currentSdk = sdkInt,
                requiredApiDescription = "ActivityOptions.setLaunchWindowingMode / FEATURE_FREEFORM_WINDOW_MANAGEMENT",
                requiredPermission = "None (System/OEM window manager controlled)",
                oemDependencyNotes = oem.multitaskingNotes,
                supportLevel = if (freeform) SupportLevel.FULLY_SUPPORTED else SupportLevel.PARTIALLY_SUPPORTED,
                requiresUserSettingsAction = !freeform,
                requiresReboot = false,
                knownLimitations = "Android blocks regular apps from forcing third-party apps into floating windows unless native freeform/multi-window is enabled.",
                fallbackBehavior = "Provides standard launch + guided Split-Screen & OEM Floating Window instructions."
            ),
            CapabilityEntry(
                featureId = "thermal_headroom_api",
                featureName = "Hardware Thermal Status & Headroom API",
                minSdkRequired = 29,
                currentSdk = sdkInt,
                requiredApiDescription = "PowerManager.getCurrentThermalStatus (API 29+) / getThermalHeadroom (API 30+)",
                requiredPermission = "None",
                oemDependencyNotes = "Requires OEM HAL thermal sensor reporting.",
                supportLevel = if (sdkInt >= 29) SupportLevel.FULLY_SUPPORTED else SupportLevel.PARTIALLY_SUPPORTED,
                requiresUserSettingsAction = false,
                requiresReboot = false,
                knownLimitations = "Does not expose proprietary per-core CPU/GPU die temperatures on unrooted devices.",
                fallbackBehavior = "Falls back to BatteryManager EXTRA_TEMPERATURE (Battery Celsius)."
            ),
            CapabilityEntry(
                featureId = "live_fps_monitoring",
                featureName = "Third-Party Game Live FPS Readout",
                minSdkRequired = 26,
                currentSdk = sdkInt,
                requiredApiDescription = "Display.getRefreshRate (Display Hz) vs Privileged SurfaceFlinger",
                requiredPermission = "Restricted by Android Sandbox",
                oemDependencyNotes = "Android security isolates each game's SurfaceFlinger frame pipeline from normal apps.",
                supportLevel = SupportLevel.LIMITED_OR_UNSUPPORTED.let { SupportLevel.PARTIALLY_SUPPORTED },
                requiresUserSettingsAction = false,
                requiresReboot = false,
                knownLimitations = "Normal Android apps cannot read another game's private FPS without root/Shizuku/ADB. We never show fake FPS.",
                fallbackBehavior = "Displays real Display Refresh Rate (Hz), booster UI frame pacing, and manual Lag Replay Markers."
            )
        )
    }
}
